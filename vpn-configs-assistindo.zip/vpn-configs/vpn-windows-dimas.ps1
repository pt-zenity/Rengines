#Requires -RunAsAdministrator
# Windows SSTP VPN Setup - Assistindo Infrastructure
# Credential Set 1: dimas-assistindo@sis1.net / gundulskinny
# Server: vpn.sis1.net (139.0.20.27)

$VpnName = "Assist-VPN-Dimas"
$ServerAddress = "vpn.sis1.net"
$Username = "dimas-assistindo@sis1.net"
$Password = "gundulskinny"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Assistindo SSTP VPN Setup (Windows)" -ForegroundColor Cyan
Write-Host "  User: $Username" -ForegroundColor Cyan
Write-Host "  Server: $ServerAddress" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# Remove existing VPN if present
$existing = Get-VpnConnection -Name $VpnName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "[*] Removing existing VPN connection: $VpnName"
    Remove-VpnConnection -Name $VpnName -Force -ErrorAction SilentlyContinue
}

# Create SSTP VPN connection
Write-Host "[*] Creating SSTP VPN connection..."
Add-VpnConnection `
    -Name $VpnName `
    -ServerAddress $ServerAddress `
    -TunnelType SSTP `
    -EncryptionLevel Required `
    -AuthenticationMethod MSChapv2 `
    -SplitTunneling $false `
    -RememberCredential `
    -Force

# Set credentials
Write-Host "[*] Setting credentials..."
$cred = New-Object System.Management.Automation.PSCredential($Username, (ConvertTo-SecureString $Password -AsPlainText -Force))
Set-VpnConnectionUsernamePassword -ConnectionName $VpnName -Username $Username -Password $Password

# Configure to ignore certificate validation (self-signed cert)
Write-Host "[*] Configuring certificate handling (self-signed)..."
$regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\RasMan\Parameters"
if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}
Set-ItemProperty -Path $regPath -Name "CertHash" -Value "" -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "[+] VPN connection created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "To connect:"
Write-Host "  1. Open Windows Settings > Network & Internet > VPN"
Write-Host "  2. Click 'Assist-VPN-Dimas' then Connect"
Write-Host "  3. Or run: rasdial '$VpnName'"
Write-Host ""
Write-Host "Note: Server uses self-signed certificate."
Write-Host "      You may need to accept the certificate warning on first connect."
