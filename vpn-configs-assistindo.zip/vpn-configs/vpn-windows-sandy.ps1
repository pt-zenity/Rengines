#Requires -RunAsAdministrator
# Windows SSTP VPN Setup - Assistindo Infrastructure
# Credential Set 2: sandy-assistindo@sis1.net / 272727
# Server: vpn2.sis1.net (139.0.20.28)

$VpnName = "Assist-VPN-Sandy"
$ServerAddress = "vpn2.sis1.net"
$Username = "sandy-assistindo@sis1.net"
$Password = "272727"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Assistindo SSTP VPN Setup (Windows)" -ForegroundColor Cyan
Write-Host "  User: $Username" -ForegroundColor Cyan
Write-Host "  Server: $ServerAddress" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

$existing = Get-VpnConnection -Name $VpnName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "[*] Removing existing VPN connection: $VpnName"
    Remove-VpnConnection -Name $VpnName -Force -ErrorAction SilentlyContinue
}

Write-Host "[*] Creating SSTP VPN connection..."
Add-VpnConnection `
    -Name $VpnName `
    -ServerAddress $ServerAddress `
    -TunnelType SSTP `
    -EncryptionLevel Required `
    -AuthenticationMethod MSChapv2 `
    -SplitTunneling $false `
    -RememberCredential `
    -Force

Write-Host "[*] Setting credentials..."
Set-VpnConnectionUsernamePassword -ConnectionName $VpnName -Username $Username -Password $Password

Write-Host ""
Write-Host "[+] VPN connection created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "To connect:"
Write-Host "  1. Open Windows Settings > Network & Internet > VPN"
Write-Host "  2. Click 'Assist-VPN-Sandy' then Connect"
Write-Host "  3. Or run: rasdial '$VpnName'"
