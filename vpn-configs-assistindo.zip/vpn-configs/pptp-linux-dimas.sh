#!/bin/bash
# PPTP VPN Connect Script - Assistindo Infrastructure
# Credential Set 1: dimas-assistindo@sis1.net / gundulskinny
# Server: vpn.sis1.net (139.0.20.27)
# Protocol: PPTP (Point-to-Point Tunneling Protocol)

SERVER="vpn.sis1.net"
USERNAME="dimas-assistindo@sis1.net"
PASSWORD="gundulskinny"
VPN_NAME="Assist-PPTP-Dimas"

echo "=========================================="
echo "  Assistindo PPTP VPN Connect"
echo "  User: $USERNAME"
echo "  Server: $SERVER"
echo "=========================================="

if ! command -v pptpsetup &> /dev/null && ! command -v pppd &> /dev/null; then
    echo "ERROR: PPTP client not found!"
    echo "Install with: apt-get install pptp-linux ppp"
    exit 1
fi

# Configure PPTP connection
if command -v pptpsetup &> /dev/null; then
    echo "[*] Creating PPTP tunnel config..."
    pptpsetup --create "$VPN_NAME" --server "$SERVER" --username "$USERNAME" --password "$PASSWORD" --encrypt --start
else
    # Manual pppd config
    echo "[*] Using pppd directly..."
    pppd pty "pptp $SERVER --nolaunchpppd" \
        name "$USERNAME" \
        password "$PASSWORD" \
        require-mschap-v2 \
        require-mppe-128 \
        file /etc/ppp/options.pptp \
        ipparam "$VPN_NAME" \
        logfd 2
fi

echo ""
echo "[*] PPTP connection initiated."
echo "[*] Check 'ip addr' for ppp interface."
echo "[*] Route traffic with: ip route add 10.0.0.0/8 dev ppp0"
