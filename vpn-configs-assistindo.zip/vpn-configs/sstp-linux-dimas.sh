#!/bin/bash
# SSTP VPN Connect Script - Assistindo Infrastructure
# Credential Set 1: dimas-assistindo@sis1.net / gundulskinny
# Server: vpn.sis1.net (139.0.20.27)
# Protocol: SSTP (Secure Socket Tunneling Protocol)

SERVER="vpn.sis1.net"
USERNAME="dimas-assistindo@sis1.net"
PASSWORD="gundulskinny"

echo "=========================================="
echo "  Assistindo SSTP VPN Connect"
echo "  User: $USERNAME"
echo "  Server: $SERVER"
echo "=========================================="

# Check for sstp-client
if ! command -v sstpc &> /dev/null; then
    echo "ERROR: sstp-client not found!"
    echo "Install with: apt-get install sstp-client ppp"
    exit 1
fi

# Check for ppp
if [ ! -c /dev/ppp ]; then
    echo "WARNING: /dev/ppp not found. Loading ppp kernel module..."
    modprobe ppp_generic 2>/dev/null || true
    if [ ! -c /dev/ppp ]; then
        echo "ERROR: PPP kernel module not available."
        echo "Run: sudo modprobe ppp_generic"
        exit 1
    fi
fi

echo "[*] Connecting to $SERVER..."
echo "[*] Protocol: SSTP (port 443)"
echo "[*] Auth: MS-CHAPv2"
echo ""

# Connect via SSTP
# --cert-warn : Skip self-signed certificate warning
# --log-stderr : Log to stderr for debugging
# --log-level 3 : Verbose logging
sstpc "$SERVER" \
    --user "$USERNAME" \
    --password "$PASSWORD" \
    --cert-warn \
    --log-stderr \
    --log-level 3 \
    2>&1

# If sstpc exits, check for TUN device issues
echo ""
echo "[*] Connection ended."
echo "[*] If you see 'couldn't open ppp device', ensure TUN/TAP is enabled:"
echo "    sudo modprobe tun"
