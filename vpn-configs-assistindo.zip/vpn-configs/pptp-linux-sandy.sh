#!/bin/bash
# PPTP VPN Connect Script - Assistindo Infrastructure
# Credential Set 2: sandy-assistindo@sis1.net / 272727
# Server: vpn2.sis1.net (139.0.20.28)
# Protocol: PPTP (Point-to-Point Tunneling Protocol)

SERVER="vpn2.sis1.net"
USERNAME="sandy-assistindo@sis1.net"
PASSWORD="272727"
VPN_NAME="Assist-PPTP-Sandy"

echo "=========================================="
echo "  Assistindo PPTP VPN Connect"
echo "  User: $USERNAME"
echo "  Server: $SERVER"
echo "=========================================="

if ! command -v pptpsetup &> /dev/null && ! command -v pppd &> /dev/null; then
    echo "ERROR: PPTP client not found!"
    echo "Install with: apt-get install pptp-linux ppp"
    exit 1
fi

if command -v pptpsetup &> /dev/null; then
    echo "[*] Creating PPTP tunnel config..."
    pptpsetup --create "$VPN_NAME" --server "$SERVER" --username "$USERNAME" --password "$PASSWORD" --encrypt --start
else
    echo "[*] Using pppd directly..."
    pppd pty "pptp $SERVER --nolaunchpppd" \
        name "$USERNAME" \
        password "$PASSWORD" \
        require-mschap-v2 \
        require-mppe-128 \
        file /etc/ppp/options.pptp \
        ipparam "$VPN_NAME" \
        logfd 2
fi

echo ""
echo "[*] PPTP connection initiated."
