#!/bin/bash
# SSTP VPN Connect Script - Assistindo Infrastructure
# Credential Set 2: sandy-assistindo@sis1.net / 272727
# Server: vpn2.sis1.net (139.0.20.28)
# Protocol: SSTP (Secure Socket Tunneling Protocol)

SERVER="vpn2.sis1.net"
USERNAME="sandy-assistindo@sis1.net"
PASSWORD="272727"

echo "=========================================="
echo "  Assistindo SSTP VPN Connect"
echo "  User: $USERNAME"
echo "  Server: $SERVER"
echo "=========================================="

if ! command -v sstpc &> /dev/null; then
    echo "ERROR: sstp-client not found!"
    echo "Install with: apt-get install sstp-client ppp"
    exit 1
fi

if [ ! -c /dev/ppp ]; then
    echo "WARNING: /dev/ppp not found. Loading ppp kernel module..."
    modprobe ppp_generic 2>/dev/null || true
    if [ ! -c /dev/ppp ]; then
        echo "ERROR: PPP kernel module not available."
        exit 1
    fi
fi

echo "[*] Connecting to $SERVER..."
echo "[*] Protocol: SSTP (port 443)"
echo "[*] Auth: MS-CHAPv2"
echo ""

sstpc "$SERVER" \
    --user "$USERNAME" \
    --password "$PASSWORD" \
    --cert-warn \
    --log-stderr \
    --log-level 3 \
    2>&1

echo ""
echo "[*] Connection ended."
